﻿namespace FMGSuiteDevTest.Data.Database
{
    public interface IDatabaseBootstrap
    {
    }
}