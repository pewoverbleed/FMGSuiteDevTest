﻿namespace FMGSuiteDevTest.Data.Database
{
    public class DatabaseConfig
    {
        public string Name {get; set;}
    }
}
