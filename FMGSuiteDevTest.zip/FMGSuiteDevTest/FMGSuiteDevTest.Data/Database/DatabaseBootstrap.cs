﻿using Dapper;
using Microsoft.Data.Sqlite;
using System.Linq;

namespace FMGSuiteDevTest.Data.Database
{
    public class DatabaseBootstrap : IDatabaseBootstrap
    {
        private readonly DatabaseConfig databaseConfig;
        public DatabaseBootstrap(DatabaseConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }

        public void Setup()
        {
            using var connection = new SqliteConnection($"Data Source={databaseConfig.Name}");
            var table = connection.Query<string>("Select name FROM sqlite_master WHERE type='table' AND name = 'FMG Suite';");
            var tableName = table.FirstOrDefault();
            if (!string.IsNullOrEmpty(tableName) && tableName == "Campaign")
                return;

            connection.Execute("Create Table Campaign (" +
                                "[CampaignID]  INT IDENTITY (1, 1) NOT NULL," +
                                "[Identifier]        UNIQUEIDENTIFIER CONSTRAINT[DF__Campaign__Identi__3C1FE2D6] DEFAULT(newsequentialid()) NOT NULL," +
                                "[PartyID]           INT              NOT NULL," +
                                "[Name]              NVARCHAR(150)   NOT NULL," +
                                "[UTM_Medium]        NVARCHAR(50)    NOT NULL," +
                                "[UTM_Source]        NVARCHAR(50)    NOT NULL," +
                                "[UTM_Term]          NVARCHAR(50)    NOT NULL," +
                                "[URL]               NVARCHAR(2000)  NULL," +
                                "[DateTimeCreated]   DATETIME         CONSTRAINT[DF__Campaign__DateTi__3D14070F] DEFAULT(getutcdate()) NOT NULL," +
                                "[AssetIdentifier]   UNIQUEIDENTIFIER NULL," +
                                "[NumberOfContacts]  INT              NULL," +
                                "[PartyCampaignId]   INT              NULL," +
                                "[DateTimeScheduled] DATETIME         NULL," +
                                "[DateTimeDeleted]   DATETIME         NULL," +
                                "[DateTimeSent]      DATETIME         NULL," +
                                "[IsQueued]          BIT              CONSTRAINT[DF_nwsltr_Campaign_IsQueued] DEFAULT((0)) NOT NULL," +
                                "[EmailTemplateId]   INT              NULL," +
                                "[PersonaId]         INT              NULL," +
                                "[EmailTypeId]       INT              CONSTRAINT[DF_nwsltr_Campaign_EmailTypeId] DEFAULT((0)) NOT NULL," +
                                "[MasterCampaignId]  INT              NULL," +
                                "[SendAsType]        INT              CONSTRAINT[DF__Campaign__SendAs__7599EE02] DEFAULT((0)) NOT NULL," +
                                "[ApiClient]         UNIQUEIDENTIFIER NULL," +
                                "CONSTRAINT[PK_Campaign] PRIMARY KEY CLUSTERED([CampaignID] ASC)");
        }
    }
}
