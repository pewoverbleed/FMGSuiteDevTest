﻿using FMGSuiteDevTest.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FMGSuiteDevTest.Data.Interfaces
{
    public interface ICampaignRepository
    {
        Campaign InsertCampaigns(Campaign campaign);
        Task<IEnumerable<int>> InsertCampaignsAsync(Campaign campaign);

        List<Campaign> GetScheduledCampaigns(int partyId);

        List<Campaign> GetSentCampaigns(int partyId);

        Campaign GetCampaignByCampaignID(int campaignId);

        Campaign CancelCampaignByCampaignId(int campaignId);

        void CancelCampaignByPartyId(int partyId);
    }
}
