﻿using FMGSuiteDevTest.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FMGSuiteDevTest.Data.Interfaces
{
    public interface ICampaignMessageRepository
    {
        List<CampaignMessage> GetCampaignSummaryDataByCampaignID(int campaignId);
        void AddCampaignMessage(int campaignId, int contactId);
        public Task AddCampaignMessageAsync(int campaignId, int[] contactIDs);
    }
}
