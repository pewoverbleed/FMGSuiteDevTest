﻿using FMGSuiteDevTest.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace FMGSuiteDevTest.Data.Interfaces
{
    public interface ICampaignMessageRepository
    {
        List<CampaignMessage> GetCampaignSummaryDataByCampaignID(int campaignId);
        void AddCampaignMessage(int campaignId, int contactId);
    }
}
