﻿using Dapper;
using FMGSuiteDevTest.Data.Interfaces;
using FMGSuiteDevTest.Data.Models;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace FMGSuiteDevTest.Data.Repositories
{
    public class CampaignRepository : ICampaignRepository
    {
        private IDbConnection db;

        public CampaignRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }

        public Campaign InsertCampaigns(Campaign campaign)
        {
            string sqlQuery = "INSERT INTO [nwsltr].[Campaign] (PartyID, Name, UTM_Medium, UTM_Source, UTM_Term, AssetIdentifier, DateTimeScheduled) " +
                "VALUES (@PartyID, @Name, @UTM_Medium, @UTM_Source, @UTM_Term, @AssetIdentifier, @DateTimeScheduled);" +
                "SELECT CAST (SCOPE_IDENTITY() as int)";

            var campaignParams = new
            {
                campaign.PartyID,
                campaign.Name,
                campaign.UTM_Medium,
                campaign.UTM_Source,
                campaign.UTM_Term,
                campaign.AssetIdentifier,
                campaign.DateTimeScheduled
            };

            var campaignId = db.Query<int>(sqlQuery, campaignParams).SingleOrDefault();
            campaign.CampaignID = campaignId;

            return campaign;
        }


        public List<Campaign> GetScheduledCampaigns(int partyId)
        {
            var sqlQuery = "SELECT * FROM [nwsltr].[Campaign] " +
                "WHERE PartyID = @PartyID AND DateTimeScheduled IS NOT NULL " +
                "ORDER BY DateTimeScheduled ASC";

            return db.Query<Campaign>(sqlQuery, new { @PartyID = partyId }).ToList();
        }

        public List<Campaign> GetSentCampaigns(int partyId)
        {
            var sqlQuery = "SELECT * FROM [nwsltr].[Campaign] WHERE PartyID = @PartyID " +
                "AND DateTimeSent IS NOT NULL ORDER BY DateTimeSent ASC";
            return db.Query<Campaign>(sqlQuery, new { @PartyID = partyId }).ToList();
        }

        public Campaign GetCampaignByCampaignID(int campaignId)
        {
            var sqlQuery = "SELECT TOP 1 * FROM [nwsltr].[Campaign] WHERE CampaignID = @CampaignID";
            return db.Query<Campaign>(sqlQuery, new { @CampaignID = campaignId }).SingleOrDefault();
        }

        public Campaign CancelCampaignByCampaignId(int campaignId)
        {
            var sqlQuery = "UPDATE [nwsltr].[Campaign] SET DateTimeDeleted = GETDATE() WHERE CampaignID = @CampaignID;";

            db.Query<Campaign>(sqlQuery, new { @CampaignID = campaignId });
            return GetCampaignByCampaignID(campaignId);
        }

        public void CancelCampaignByPartyId(int partyId)
        {
            var sqlQuery = "UPDATE [nwsltr].[Campaign] SET DateTimeDeleted = GETDATE() WHERE PartyId = @PartyId;";

            db.Query<Campaign>(sqlQuery, new { @PartyId = partyId });            
        }
    }
}
