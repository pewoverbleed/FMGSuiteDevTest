﻿using Dapper;
using FMGSuiteDevTest.Data.Interfaces;
using FMGSuiteDevTest.Data.Models;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MoreLinq;

namespace FMGSuiteDevTest.Data.Repositories
{
    public class CampaignMessageRepository : ICampaignMessageRepository
    {
        private IDbConnection db;

        public CampaignMessageRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }

        public List<CampaignMessage> GetCampaignSummaryDataByCampaignID(int campaignId)
        {
            var sqlQuery = "SELECT distinct ContactID FROM [nwsltr].[CampaignMessage] " +
                "WHERE CampaignID = @CampaignID AND ContactID IS NOT NULL";

            return db.Query<CampaignMessage>(sqlQuery, new { @CampaignID = campaignId }).ToList();
        }

        public void AddCampaignMessage(int campaignId, int contactId)
        {
            var sqlQuery = "INSERT INTO [nwsltr].[CampaignMessage] ([CampaignID], [ContactID]) " +
                "VALUES(@CampaignID, @ContactID) SELECT CAST (SCOPE_IDENTITY() as int)";

            db.Query<CampaignMessage>(sqlQuery, new { @CampaignID = campaignId, @ContactID = contactId });
        }

        public Task AddCampaignMessageAsync(int campaignId, int[] contactIDs)
        {
            //Note: batchSize is to limit row record inserts in sql.
            //The maximum is 1000 in Transact-SQL.
            int batchSize = 1000;

            var sqlQuery = "INSERT INTO [nwsltr].[CampaignMessage] ([CampaignID], [ContactID]) VALUES";

            foreach (IEnumerable<int> batch in contactIDs.Batch(batchSize))
            {
                var count = batch.Count();
                for (int i = 0; i < batch.Count(); i++)
                {
                    sqlQuery += string.Format("({0}, {1}),", campaignId, batch.ToList()[i]);
                }
            }

            sqlQuery = sqlQuery.Substring(0, sqlQuery.Length - 1) + ";";
            return db.QueryAsync<CampaignMessage>(sqlQuery);
        }        
    }
}
