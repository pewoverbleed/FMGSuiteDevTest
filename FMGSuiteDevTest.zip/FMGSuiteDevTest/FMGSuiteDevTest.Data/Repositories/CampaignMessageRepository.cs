﻿using Dapper;
using FMGSuiteDevTest.Data.Interfaces;
using FMGSuiteDevTest.Data.Models;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace FMGSuiteDevTest.Data.Repositories
{
    public class CampaignMessageRepository : ICampaignMessageRepository
    {
        private IDbConnection db;

        public CampaignMessageRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }

        public List<CampaignMessage> GetCampaignSummaryDataByCampaignID(int campaignId)
        {
            var sqlQuery = "SELECT distinct ContactID FROM [nwsltr].[CampaignMessage] " +
                "WHERE CampaignID = @CampaignID AND ContactID IS NOT NULL";

            return db.Query<CampaignMessage>(sqlQuery, new { @CampaignID = campaignId }).ToList();
        }

        public void AddCampaignMessage(int campaignId, int contactId)
        {
            var sqlQuery = "INSERT INTO [nwsltr].[CampaignMessage] ([CampaignID], [ContactID]) " +
                "VALUES(@CampaignID, @ContactID) SELECT CAST (SCOPE_IDENTITY() as int)";

            db.Query<CampaignMessage>(sqlQuery, new { @CampaignID = campaignId, @ContactID = contactId });
        }
    }
}
