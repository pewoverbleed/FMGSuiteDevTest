To Run the project, just click on the green start button in visual studio. 

The Swagger UI page should appear with two sections. One controller is for making request from Rest API clients like Postman, Thunder Client (via visual studio code) or other projects. 

The other can be tested from the SwaggerUI page that launches (CampaignController is for Rest API clients and CampaignSwaggerController can be used to test in browser vian input fields).

The project contains a portable database in the form of an mdf file. Before running, go to server explorer pane > right click "data connections" > Click "Add Connection". Datasource should be: "Microsoft SQL Server Database File (SqlClient)". Browse for the database file name (it is inside of the FMGSuiteDevTest.Data project inside if the App Data folder). It is called FMG Suite.mdf.

After this, just click ok and thats it, the web api app is ready to be used.