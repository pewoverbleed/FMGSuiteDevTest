﻿using FMGSuiteDevTest.Data.Interfaces;
using FMGSuiteDevTest.Data.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FMGSuiteDevTest.Controllers
{   /// <summary>
    /// NOTE: In order to have access to parameters in Swagger, use Campaign Swagger controller.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CampaignController : ControllerBase
    {
        private readonly ICampaignRepository _campaignRepo;
        private readonly ICampaignMessageRepository _campaignMessageRepo;

        /// <summary>
        /// Constructor for Campaign controller.
        /// </summary>
        /// <param name="campaignRepo"></param>
        /// <param name="campaignMessageRepository"></param>
        public CampaignController(ICampaignRepository campaignRepo, ICampaignMessageRepository campaignMessageRepository)
        {
            _campaignRepo = campaignRepo;
            _campaignMessageRepo = campaignMessageRepository;
        }

        /// <summary>
        /// Gets a list of emails (campaign records) scheduled by PartyId ordered by soonest to send.
        /// </summary>
        /// <param name="partyId"></param>
        /// <returns>An 'Ok' result with a campaign object.</returns>
        [HttpGet]
        [Route("GetUpcomingCampaigns")]
        public ActionResult<Campaign> GetUpcomingCampaigns([FromBody] Campaign campaignParam)
        {
            List<Campaign> campaigns = _campaignRepo.GetScheduledCampaigns(campaignParam.PartyID);

            return Ok(campaigns);
        }

        /// <summary>
        /// Gets a list of emails (campaign records) sent by PartyId ordered by most recent.
        /// </summary>
        /// <param name="partyId"></param>
        /// <returns>An 'Ok' result with a campaign object.</returns>
        [HttpGet]
        [Route("GetMostRecentCampaigns")]
        public ActionResult<Campaign> GetMostRecentCampaigns([FromBody] Campaign campaignParam)
        {
            List<Campaign> campaigns = _campaignRepo.GetSentCampaigns(campaignParam.PartyID);

            return Ok(campaigns);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <returns>An 'Ok' result with an object containing a Campaign object and summary of the object.</returns>
        [HttpGet]
        [Route("GetCampaignSummaryData")]
        public ActionResult<Campaign> GetCampaignSummaryData([FromBody] Campaign campaignParam)
        {
            Campaign campaign = _campaignRepo.GetCampaignByCampaignID(campaignParam.CampaignID);
            if (campaign is null)
            {
                return NotFound();
            }
            List<CampaignMessage> campaignMessages = _campaignMessageRepo.GetCampaignSummaryDataByCampaignID(campaignParam.CampaignID);
            var campaignSummaryData = new { Campaign = campaign, Summary = string.Format("This Campaign has {0} contacts.", campaignMessages.Count) };

            return Ok(campaignSummaryData);
        }

        /// <summary>
        /// Sends an email to an N number of contacts.
        /// </summary>
        /// <param name="partyID"></param>
        /// <param name="assetId"></param>
        /// <param name="dateTimeScheduled"></param>
        /// <param name="contactIDs"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SendEmailToContacts")]
        public ActionResult<Campaign> SendEmailToContacts([FromBody] Campaign campaignParam)
        {
            var partyID = campaignParam.PartyID;
            var assetId = campaignParam.AssetIdentifier;
            var dateTimeScheduled = campaignParam.DateTimeScheduled;
            var contactIDs = campaignParam.ContactIDs;

            if (dateTimeScheduled < DateTime.Now)
            {
                return NotFound("Campaign cannot be scheduled in the past");
            }

            Campaign campaign = new Campaign()
            {
                PartyID = partyID,
                Name = string.Format("Test User"),
                UTM_Medium = string.Empty,
                UTM_Source = string.Empty,
                UTM_Term = string.Empty,
                AssetIdentifier = assetId,
                DateTimeScheduled = dateTimeScheduled
            };

            Campaign newCampaign = _campaignRepo.InsertCampaigns(campaign);
            foreach (var id in contactIDs)
            {
                //Do something with Campaign Message table
                _campaignMessageRepo.AddCampaignMessage(newCampaign.CampaignID, id);
            }

            return Ok(newCampaign);
        }

        /// <summary>
        /// Asynchronously sends an email to an N number of contacts.
        /// </summary>
        /// <param name="partyID"></param>
        /// <param name="assetId"></param>
        /// <param name="dateTimeScheduled"></param>
        /// <param name="contactIDs"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SendEmailToContactsAsync")]
        public async Task<ActionResult<Campaign>> SendEmailToContactsAsync([FromBody] Campaign campaignParam)
        {
            var partyID = campaignParam.PartyID;
            var assetId = campaignParam.AssetIdentifier;
            var dateTimeScheduled = campaignParam.DateTimeScheduled;
            var contactIDs = campaignParam.ContactIDs;

            if (dateTimeScheduled < DateTime.Now)
            {
                return NotFound("Campaign cannot be scheduled in the past");
            }

            Campaign newCampaign = new Campaign();
            Campaign campaign = new Campaign()
            {
                PartyID = partyID,
                Name = string.Format("Test User"),
                UTM_Medium = string.Empty,
                UTM_Source = string.Empty,
                UTM_Term = string.Empty,
                AssetIdentifier = assetId,
                DateTimeScheduled = dateTimeScheduled
            };
            newCampaign.CampaignID = _campaignRepo.InsertCampaigns(campaign).CampaignID;

            //Insert record into Campaign Message table
            await _campaignMessageRepo.AddCampaignMessageAsync(newCampaign.CampaignID, contactIDs);

            return Ok(newCampaign.CampaignID);
        }

        /// <summary>
        /// Cancels an email to be sent (for emails not sent yet).
        /// </summary>
        /// <param name="campaignId"></param>
        /// <returns>Either an 'Ok' result with a campaign object, 
        /// or a NotFound result with an error message.'.</returns>
        [HttpPatch]
        [Route("CancelEmail")]
        public ActionResult<Campaign> CancelEmail([FromBody] Campaign campaignParam)
        {
            Campaign campaign = _campaignRepo.GetCampaignByCampaignID(campaignParam.CampaignID);
            bool isSent = campaign.DateTimeSent != DateTime.MinValue;

            if (isSent || campaign is null)
            {
                return NotFound("Can only cancel emails not yet sent");
            }

            //Cancel email
            Campaign cancelledCampaign = _campaignRepo.CancelCampaignByCampaignId(campaignParam.CampaignID);

            return Ok(cancelledCampaign);
        }
    }
}
